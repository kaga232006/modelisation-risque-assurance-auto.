# Modélisation du risque en assurance automobile

## Présentation
Ce projet utilise le langage R pour simuler un portefeuille fictif de 3 000 assurés et étudier le risque en assurance automobile.

Il modélise :
- la fréquence des sinistres avec une loi de Poisson ;
- le coût des sinistres avec une loi Gamma ;
- la fréquence observée selon l'âge et la puissance du véhicule ;
- la distribution des coûts et une estimation de la prime pure.

## Contenu du dépôt
- `projet.R` : script R utilisé pour réaliser la simulation.
- `rapport_projet.pdf` : rapport présentant la démarche, les graphiques et leur interprétation.
- `frequence_selon_age.pdf` : graphique de fréquence par tranche d'âge.
- `frequence_selon_puissance.pdf` : graphique de fréquence par puissance.
- `distribution_couts_totaux.pdf` : histogramme des coûts totaux, zéros inclus.
- `distribution_couts_positifs.pdf` : histogramme des coûts positifs.

## Exécution
1. Installer R depuis https://cran.r-project.org/.
2. Ouvrir `projet.R` dans RStudio ou dans R.
3. Exécuter le script du début à la fin.

Le script utilise les fonctions de base de R ; aucune bibliothèque externe n'est nécessaire.

## Méthodes
Le paramètre de fréquence individuel est défini dans le script par :

`lambda = exp(-2 + 0.015 * (age - 40) + 0.04 * (puissance - 8))`

Le nombre de sinistres est simulé selon une loi de Poisson tenant compte de la durée d'exposition. Les coûts individuels sont simulés selon une loi Gamma de forme 2 et d'échelle 600, soit un coût moyen théorique de 1 200 par sinistre.

## Limites et précautions
Les données sont simulées et ne représentent pas les données réelles d'un assureur. Les résultats dépendent des hypothèses choisies et de la graine aléatoire fixée dans le script.

À vérifier dans le script d'origine : la puissance est simulée de 4 à 16, alors que les classes du graphique s'arrêtent à 15. Les observations de puissance 16 ne sont donc pas prises en compte dans ce regroupement. Les libellés des deux dernières classes d'âge peuvent également être harmonisés.

## Auteur
Projet académique — à compléter avec le nom de l'étudiante et l'année de réalisation.
