#PROJET: MODELISATION DU RISQUE EN ASSURANCE AUTOMOBILE
# INITIALISATION DU PROGRAMME
set.seed(123)
#Nombre d' assurés dans notre portefeuille
n=3000
# afficher le nombre d'assurés
print(n)

#Caracteristiques des assurés
#Age des assures: entre 18 et 75 ans
age =sample(18:75,n,replace=TRUE)
#Puissance des vehicules : entre 4 et 15 CHEVEAUX
puissance=sample(4:16,n,replace=TRUE)
#DUREE D' assurance dans l'anee
exposition=runif(n,min=0.5,max=1)
# affiche les 10 premiers assures
head(data.frame(age,puissance, exposition),10)
# Modelisation DE LA FREQUENCE DES SINISTRES 
#UTILISATION DE LA LOI DE POISSON
lambda=exp(-2+0.015*(age-40)+0.04*(puissance-8))
sinistres=rpois(n,lambda*exposition)
head(data.frame(age,puissance, exposition,sinistres),10)

# Nombre total de sinistres
sum(sinistres)
#nombre d'assures sans sinistre 
sum(sinistres==0)
# nombre d'assures avec au moins un sinistre 
sum(sinistres>0)
#Freqence moyenne observée par anée-assurée
sum(sinistres)/sum(exposition)

#MODELISATION DU COUT DS SINISTRES 
#Cout moyen theorique d' un sinistre 
cout_moyen=1200
# Initialisation du cout total pour chaque assure
cout_total=numeric(n)

# simulation des couts
for (i in 1:n) {
  if (sinistres[i]>0) {
    cout_total[i]=sum(rgamma( sinistres[i],shape=2,scale =600))
  }
}
head(cout_total,10)
sum (cout_total)
mean(cout_total)
mean(cout_total[cout_total>0])
hist(cout_total,breaks=50,main="Distribution des couts totaux",xlab="cout_total",col="blue")
hist(cout_total[cout_total>0],breaks=50,main="Distribution des couts (sinistres>0",xlab="cout",col="orange")

prime_pure=sum(cout_total/sum(exposition))
print(prime_pure)
sum(exposition)
# FREQUENCE DES SINISTRE SELON L'AGE 
# CREATION DES CATEGORIES D'AGE
classe_age =cut(age,breaks=c(17,25,35,45,55,65,75),labels=c("18-25","26-35","36-45","46-55","56,65","66,75"),include.lowest = TRUE)
#regroupement des donnees 
donees_age=aggregate(cbind(sinistres,exposition),by=list(classe_age),FUN=sum)
#Calcul de la freaquence par annes d' exposition
donees_age$frequence=donees_age$sinistres/donees_age$exposition
#Affichage
print(donees_age)
#Graphique
barplot( height=donees_age$frequence,names.arg=donees_age$Group.1,main="Frequence des sinistres selon l'age ",xlab="Tranche d' age ",ylab="frequence des sinistres",col="skyblue" )

# FREQUENCE DES SINISTRE SELON La puissance  
# CREATION DES CATEGORIES D'AGE
classe_puissance =cut(puissance,breaks=c(3,6,9,12,15),labels=c("4-6","7-9","10-12","13-15"),include.lowest = TRUE)
#regroupement des donnees 
donees_puissance=aggregate(cbind(sinistres,exposition),by=list(classe_puissance),FUN=sum)
#Calcul de la freaquence par annes d' exposition
donees_puissance$frequence=donees_puissance$sinistres/donees_puissance$exposition
#Affichage
print(donees_puissance)
#Graphique
barplot( height=donees_puissance$frequence,names.arg=donees_puissance$Group.1,main="Frequence des sinistres selon la puissane  ",xlab="puissance du vehicule ",ylab="frequence des sinistres",col="green" )
